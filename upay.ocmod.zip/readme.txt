=== UPayments Payment Gateway for Opencart ===
Contributors: UPayments
UPayments payments, woocommerce, payment gateway, UPayments, pay with UPayments, credit card, knet, samsung pay, Apple Pay, Google Pay

== Prerequisites ==
Upayments account
OpenCart 4.0.2.2

== Installation ==

1.Download the plugin file 
2.Sign in to your OpenCart 4 admin.
3.Go to Extensions > Installer.
4.Click on the Upload icon, and then select the downloaded file.
5.Click on the Install icon of UPayments in the list of installed extensions.
6.Once installed, click on the Extensions option in the main menu.
7.Select Extensions and then Payments inside the Choose the extension type.
8.In the extensions list of Payments below, find UPay, and then click on the Install icon.

== You need to make two specific extra actions in the OpenCart Admin ==

1.Enable Telephone Display and Telephone Required at System > Settings > Edit your Store > Option > Account

2.Enable the option Lax in Session Same-Site Cookie at System > Settings > Edit your Store > Server


== Configuration ==
Sign in to your OpenCart Admin.
Go to Extensions > Extensions > Payments > UPay > Edit Icon.
On the UPay configuration page, configure the:
 -Api Key provided by UPayments
 -Order status
 -Enable status
 -Sort Order
Click on save Button
